import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class fetchdoctordetail extends HttpServlet
{

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        int Doctorid = (Integer.parseInt(request.getParameter("Doctorid")));
        
        JSONObject json = new JSONObject();
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs = stmt.executeQuery("select * from doctors_info2 where doctor_id=" + Doctorid );

           if (rs.next())
            {
                String Profile_Photo = rs.getString("profile_photo");
                String Doctor_Name = rs.getString("Doctor_name");
                String Qualification = rs.getString("Qualification");
                String Experience = rs.getString("Experience");
                String Address = rs.getString("Address");
                
                json.put("profile_photo", Profile_Photo);
                json.put("Doctor_name", Doctor_Name);
                json.put("Qualification", Qualification);
                json.put("Experience", Experience);
                json.put("Address", Address);
                
            }

        } catch (Exception e)
        {
            e.printStackTrace();
        }
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt2 = conn2.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs2 = stmt2.executeQuery("select * from gallery where did=" + Doctorid );
            JSONArray jsonarray2 = new JSONArray();
            while (rs2.next())
            {

                String photo_path = rs2.getString("photo_path");

                JSONObject js2 = new JSONObject();
                js2.put("photo_path", photo_path);

                jsonarray2.add(js2);
            }
            json.put("Gallery_of_Doctors", jsonarray2);

        } catch (Exception ex)
        {
            ex.printStackTrace(out);
        }
        
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn3 = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt3 = conn3.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs3 = stmt3.executeQuery("select AVG(RatingValue) as R1 from rating  where Doctorid='" + Doctorid + "' ");
            JSONArray jsonarray3 = new JSONArray();
            if (rs3.next())
            {
                 float rating = rs3.getFloat("R1");
                 
                
                    json.put("rating", rating);
                            
            }
            
            out.println(json);
        }
          catch(Exception e)
        {
            e.printStackTrace();
        }
   
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        doGet(request, response);
    }
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

}
