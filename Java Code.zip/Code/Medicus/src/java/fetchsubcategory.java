

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class fetchsubcategory extends HttpServlet {

   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String catname = request.getParameter("Category_Name");
        try
        {
                Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,  ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs = stmt.executeQuery("select * from sub_category where Category_Name='"+catname+"'");
            System.out.println("ResultSet Created\n\n");
            
            JSONObject json= new JSONObject();
            JSONArray jsonarray=new JSONArray();
            
            
            
              while(rs.next())
                 {
                     String Sub_Category_Name = rs.getString("Sub_Category_Name");
                   
                     
                     JSONObject js= new JSONObject();
                     js.put("Sub_Category_Name",Sub_Category_Name);
              
                     
                     jsonarray.add(js);
                 
                 }
                 json.put("Sub_categories",jsonarray);
                 out.println(json);
        }
        
        catch(Exception e)
        {
            e.printStackTrace(out);
        }
    }

      
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
