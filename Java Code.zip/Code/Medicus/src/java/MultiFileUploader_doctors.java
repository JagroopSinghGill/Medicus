import java.io.*;
import java.sql.*;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import javax.servlet.http.Part;

@MultipartConfig
public class MultiFileUploader_doctors extends HttpServlet
{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        try
        {
            PrintWriter out = response.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<link href=\"css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\"/>");
            out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
            out.println("<title>Servlet MyFileUploader</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<center>");

            //Part part1= request.getPart("fn");
            Collection<Part> parts = request.getParts();
            String ans = "";
            String myphoto="";

            
            String absolutepath = request.getServletContext().getRealPath("/myuploads");

            for (Part part : parts)
            {

                String filename = vmm2.FileUploader.savefileonserver(part, absolutepath);
              //String filename=vmm2.FileUploader.savefileonserver(part,absolutepath,newfilename);
                //you can pass third paramater to change filename on serverside

                if (filename.equals("not-a-file"))
                {
                    ans += "<br>" + "---";
                } else
                {
                    ans += "<br>" + filename;
                    myphoto=filename;
                }
            }
            
            Class.forName("com.mysql.jdbc.Driver");
       System.out.println("Driver Loading Done");
       
       
       Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","Wahegurusb@13");
       System.out.println("Connection Created");
       
       Statement stmt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
       System.out.println("Statement Created");
       
       ResultSet rs=stmt.executeQuery("Select * from main_category_info");
       System.out.println("Result Set Created");
       
       

            String c = request.getParameter("cat_name");
            out.println("<h1>New Category Added</h1>");
            out.println("<h2>Category Name:  " + c + "</h2>");
            System.out.println(c);

            String d = request.getParameter("Description");
            out.println("<h3> Description: " + d + "</h3>");
            System.out.println(d);

            out.println("<h2>" + ans + "</h2>");
            out.println("<a href=\"view_main_category.jsp\" style=\"background-color: #00598e;padding: 15px 10px;border: 2px solid #e7e7e7;font-size: 125% \" class=\"btn  btn-success\">OK</a><br>\n");
            out.println("</center>");
            out.println("</body>");
            out.println("</html>");
            
            
          
                rs.moveToInsertRow();
                rs.updateString("cat_name", c);
                rs.updateString("Description", d);
                rs.updateString("Icon","./myuploads"+"/"+myphoto );
                rs.insertRow();
           
            
        } 
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    
    
  
}
