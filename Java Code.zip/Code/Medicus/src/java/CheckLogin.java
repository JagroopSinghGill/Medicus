import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.*;

public class CheckLogin extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/plain");

        PrintWriter out = response.getWriter();

        String u = request.getParameter("un");
        String p = request.getParameter("ps");

        System.out.println("Request from Mobile " + u + " " + p);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading Done");

            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");

            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");

            ResultSet rs = stmt.executeQuery("Select * from user where  username='" + u + "' and password='" + p + "'");
            System.out.println("Result Set Created");
            ///////////  Logic To Check username and password  /////////// 
            ////// Actual logic use DB and then return success and fail

            boolean matchfound = false;
            if (rs.next()) {
                out.println("success");

            } else {
                out.println("fail");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        doGet(request, response);
    }
}
