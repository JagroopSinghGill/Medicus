import java.io.*;
import java.sql.*;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import javax.servlet.http.Part;

@MultipartConfig
public class Edit_main_category extends HttpServlet
{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        try
        {
            PrintWriter out = response.getWriter();
            
            String cat_name = request.getParameter("cat_name");
            String d = request.getParameter("Description");
            String icon = request.getParameter("icon");
            System.out.println(icon);
            
            String ans = "";
            String myphoto="";

            Collection<Part> parts = request.getParts();
            String absolutepath = request.getServletContext().getRealPath("/myuploads");

            for (Part part : parts)
            {

                String filename = vmm2.FileUploader.savefileonserver(part, absolutepath);
              
                if (filename.equals("not-a-file"))
                {
                    ans += "<br>" + "---";
                } else
                {
                    ans += "<br>" + filename;
                    myphoto=filename;
                }
            }    
            
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading Done");
       
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","Wahegurusb@13");
            System.out.println("Connection Created");
       
            Statement stmt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
       
            ResultSet rs = stmt.executeQuery("select * from main_category_info where cat_name='"+cat_name+"'");
            System.out.println("Result Set Created");
       
           if(rs.next())
            {
                rs.updateString("Description", d);
                rs.updateString("Icon","./myuploads"+"/"+myphoto );
                rs.updateRow();
                rs.close();
                
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<link href=\"css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\"/>");
                out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n");
                out.println("<title>Servlet MyFileUploader</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<center>");
                out.println("<h1>Category Edited Successfully</h1>");
                out.println("<h2>Category Name:  " + cat_name + "</h2>");
                System.out.println(cat_name);

                out.println("<h3> Description: " + d + "</h3>");
                System.out.println(d);

                out.println("<h2>" + ans + "</h2>");
                out.println("<a href=\"view_main_category.jsp\" style=\"background-color: #00598e;padding: 15px 10px;border: 2px solid #e7e7e7;font-size: 125% \" class=\"btn  btn-success\">OK</a></li><br>\n");
                out.println("</center>");
                out.println("</body>");
                out.println("</html>");
            }
          
        } 
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
