var xmlhttp;
        function go1()
        {
          
            var city = document.getElementById("s1").value;
            xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = go2;
            xmlhttp.open("GET", "cookiegenerate.jsp.jsp?city=" + city, true);
            xmlhttp.send();
        }

        function go2()
        {
            if (xmlhttp.readyState === 4 && xmlhttp.status === 200)
            {
                window.location.reload();
            }
        }

        xmlhttp = new XMLHttpRequest();
        function history()
        {
            xmlhttp.onreadystatechange = history2;
            xmlhttp.open("GET", "viewbookinghistory.jsp", true);
            xmlhttp.send();
        }
        function history2()
        {
            if (xmlhttp.readyState === 4 && xmlhttp.status === 200)
            {
                window.location.reload();
            }
        }