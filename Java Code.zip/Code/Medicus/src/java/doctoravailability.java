import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class doctoravailability extends HttpServlet
{

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        int Doctorid = Integer.parseInt(request.getParameter("Doctorid"));
        String selected_date = request.getParameter("selected_date");

        
        System.out.println(selected_date);
        String a[] = selected_date.split("-");
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, Integer.parseInt(a[0]));
        cal.set(Calendar.MONTH, Integer.parseInt(a[1]) - 1);
        cal.set(Calendar.DATE, Integer.parseInt(a[2]));

        
        
        int day = cal.get(Calendar.DAY_OF_WEEK);
        String day1 = "";

        if (day == 1)
        {
            day1 = "SUNDAY";
        } else if (day == 2)
        {
            day1 = "MONDAY";
        } else if (day == 3)
        {
            day1 = "TUESDAY";
        } else if (day == 4)
        {
            day1 = "WEDNESDAY";
        } else if (day == 5)
        {
            day1 = "THURSDAY";
        } else if (day == 6)
        {
            day1 = "FRIDAY";
        } else if (day == 7)
        {
            day1 = "SATURDAY";
        }

        
        System.out.println(day1);
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");

            ResultSet rs = stmt.executeQuery("select * from doctors_info2 where doctor_id=" + Doctorid + " and " + day1 + "_working='1'");

            if (rs.next())
            {
                out.println("available"); 
                System.out.println("available"); 
            }
            else
            {
                out.println("not available");
                System.out.println("not available");
            }

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}
