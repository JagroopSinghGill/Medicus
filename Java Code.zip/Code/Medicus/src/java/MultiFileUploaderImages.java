import java.io.*;
import java.sql.*;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import javax.servlet.http.Part;

@MultipartConfig
public class MultiFileUploaderImages extends HttpServlet
{

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        try
        {
            PrintWriter out = response.getWriter();
            HttpSession session = request.getSession();
            int did = Integer.parseInt(session.getAttribute("did").toString());

            //Part part1= request.getPart("fn");
            Collection<Part> parts = request.getParts();
            String ans = "";
            String myphoto = "";

            String absolutepath = request.getServletContext().getRealPath("/clinic_pics");

            for (Part part : parts)
            {

                String filename = vmm2.FileUploader.savefileonserver(part, absolutepath);
                //String filename=vmm2.FileUploader.savefileonserver(part,absolutepath,newfilename);
                //you can pass third paramater to change filename on serverside

                if (filename.equals("not-a-file"))
                {
                    ans += "<br>" + "---";
                } else
                {
                    ans += "<br>" + filename;
                    myphoto = filename;
                }
            }

            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading Done");

            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");

            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");

            ResultSet rs = stmt.executeQuery("Select * from gallery");
            System.out.println("Result Set Created");

            String caption = request.getParameter("caption");

            rs.moveToInsertRow();
            rs.updateString("caption", caption);
            rs.updateInt("did", did);
            rs.updateString("photo_path", "./clinic_pics" + "/" + myphoto);
            rs.insertRow();

            out.println("<div class=\"row\">");

            rs = stmt.executeQuery("Select * from gallery where did=" + did);
            System.out.println("Result Set Created");

            while (rs.next())
            {
                String photo = rs.getString("photo_path");
                 caption = rs.getString("caption");
                out.println("<div class=\"col-sm-3\">");
                out.println("<img src = \""+photo+"\" style = \"width: 100%; height: 200px\" / > <br>");        
                out.println("<label>"+caption+"</label>");
                
                    out.println("</div>");    
                    
                    
                  
                    
                    
                
            }
            out.println("</div>");
        } catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

}
