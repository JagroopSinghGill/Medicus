
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import vmm.SMSSender;

public class userservlet extends HttpServlet
{

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
       
       String username= request.getParameter("username");
      String password=  request.getParameter("password");
      String mobile=  request.getParameter("mobile");
       String email= request.getParameter("email");
       
        try
        {
        Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs = stmt.executeQuery("select * from user");
            System.out.println("ResultSet Created\n\n");
            
            rs.moveToInsertRow();
            rs.updateString("username", username);
            rs.updateString("password", password);
            rs.updateString("mobile", mobile);
            rs.updateString("email", email);
            
            rs.insertRow();
            response.sendRedirect("userlogin.jsp");
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
    }
    
    
    
}


