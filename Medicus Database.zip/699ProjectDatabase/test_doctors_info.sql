-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctors_info`
--

DROP TABLE IF EXISTS `doctors_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `doctors_info` (
  `doctor_id` int(11) NOT NULL AUTO_INCREMENT,
  `Doctor_name` varchar(45) DEFAULT NULL,
  `Qualification` varchar(200) DEFAULT NULL,
  `Experience` varchar(200) DEFAULT NULL,
  `Category` varchar(45) DEFAULT NULL,
  `Sub_Category` varchar(45) DEFAULT NULL,
  `Address` varchar(300) DEFAULT NULL,
  `Description` varchar(45) DEFAULT NULL,
  `Consultation_fees` varchar(45) DEFAULT NULL,
  `Services` varchar(45) DEFAULT NULL,
  `latitude` varchar(100) DEFAULT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `monday_working` int(11) DEFAULT '0',
  `tuesday_working` int(11) DEFAULT '0',
  `wednesday_working` int(11) DEFAULT '0',
  `thursday_working` int(11) DEFAULT '0',
  `friday_working` int(11) DEFAULT '0',
  `saturday_working` int(11) DEFAULT '0',
  `sunday_working` int(11) DEFAULT '0',
  `status` varchar(45) DEFAULT 'pending',
  `morning_start_time` varchar(45) DEFAULT NULL,
  `morning_end_time` varchar(45) DEFAULT NULL,
  `evening_start_time` varchar(45) DEFAULT NULL,
  `evening_end_time` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `confirm_password` varchar(45) DEFAULT NULL,
  `profile_photo` varchar(200) DEFAULT NULL,
  `MobileNo` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors_info`
--

LOCK TABLES `doctors_info` WRITE;
/*!40000 ALTER TABLE `doctors_info` DISABLE KEYS */;
INSERT INTO `doctors_info` VALUES (4,'shubh','MBBS','5 year','Dentists','Ortho','511 Rankin Avenue, Windsor, ON, Canada','njn','65','kaint doctor','42.3067777','-83.06082579999998',1,0,1,0,1,0,1,'Approve','09:00','12:00','02:00','04:00','kaint',NULL,'./myuploads/doctor.jpg','3657735876',NULL),(5,'jagroop','Nursing','5 year','Therapists and Nutritionists','Dietition','479 Rankin Avenue, Windsor, ON, Canada','oknkn','100','kaint','42.30714949999999','-83.0610926',0,0,0,1,1,1,1,'Approve','09:00','12:00','01:00','06:00','balle',NULL,'./myuploads/doclogo.jpg','3657735867','WINDSOR'),(6,'Mandeep Singh','M.D., MBBS','10 Years','Doctors','Cardiologist','479 Rankin Avenue, Windsor, ON, Canada','Heart doctor','110','treadmill','42.30714949999999','-83.0610926',1,1,1,1,1,1,0,'Approve','10:00','12:30','2:30','5:30','oyesidhu',NULL,'./myuploads/C:\\Users\\Jagroop Singh Gill\\Documents\\NetBeansProjects\\Practo\\build\\web\\myuploads (Access is denied)','3895624589','WINDSOR'),(7,'Jagroop','MBBS','5 year','Doctors','Phsysiotherapist','479 Rankin Avenue, Windsor, ON, Canada','nice doctor','70','everykind','42.30714949999999','-83.0610926',1,1,1,0,0,0,0,'Approve','08:00','10:00','12:00','4:00','shubhdeep',NULL,'./myuploads/october legends.jpg','3657735867','WINDSOR'),(8,'jack','MBBS','5 Year','Doctors','Phsysiotherapist','479 Rankin Ave, Windsor, Ontario','Nice doctor','70','everykind of','','',1,1,1,0,0,0,0,'Approve','09:00','12:00','01:00','04:00','kaint',NULL,'./myuploads/doctor.jpg','3657735867','KINGSVILLE'),(9,'Gurpreet Singh','MD,MBBS','15years','Doctors','Cardiologist','123 Rankin ave','All Medical facilities available','80','best in class','','',1,1,1,1,1,0,0,'Approve','10:00','1:00','3:00','7:00','kidda',NULL,'./myuploads/IMG_20151230_134043.jpg','2262252589','WINDSOR');
/*!40000 ALTER TABLE `doctors_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-10 16:31:55
