import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig
public class AddDoctorServlet extends HttpServlet
{

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        try{
            PrintWriter out = response.getWriter();
        
            Collection<Part> parts = request.getParts();
            String ans = "";
            String myphoto = "./myuploads/";

            String absolutepath = request.getServletContext().getRealPath("/myuploads");

            for (Part part : parts)
            {

                String filename = vmm2.FileUploader.savefileonserver(part, absolutepath);
                //String filename=vmm2.FileUploader.savefileonserver(part,absolutepath,newfilename);
                //you can pass third paramater to change filename on serverside

                if (filename.equals("not-a-file"))
                {
                    ans += "<br>" + "---";
                } else
                {
                    ans += "<br>" + filename;
                    myphoto = filename;
                }
            }

            String name = request.getParameter("dname");
            String qual = request.getParameter("qualification");
            String exp = request.getParameter("experience");
            String category = request.getParameter("category");
            String subcat = request.getParameter("subcategory");
            String address = request.getParameter("address");
            String des = request.getParameter("description");
            String constfee = request.getParameter("fees");
            String mon = request.getParameter("m");
            String tues = request.getParameter("t");
            String wed = request.getParameter("w");
            String thurs = request.getParameter("th");
            String fri = request.getParameter("f");
            String sat = request.getParameter("sat");
            String sun = request.getParameter("sun");
            String city = request.getParameter("city");
            String morningstarttime = request.getParameter("morningstarttime");
            String morningendtime = request.getParameter("morningendtime");
            String eveningstarttime = request.getParameter("eveningstarttime");
            String eveningendtime = request.getParameter("eveningendtime");
            String service = request.getParameter("services");
            String lat = request.getParameter("latitude");
            String longt = request.getParameter("longitude");
            String password = request.getParameter("password");
            long mobile=Long.parseLong(request.getParameter("mobile"));

            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading Done");

            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");

            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");

            ResultSet rs = stmt.executeQuery("Select * from doctors_info");
            System.out.println("Result Set Created");

            rs.moveToInsertRow();
            rs.updateString("Doctor_name", name);
            rs.updateString("Qualification", qual);
            rs.updateString("Experience", exp);
            rs.updateString("Category", category);
            rs.updateString("Sub_category", subcat);
            rs.updateString("Address", address);
            
            rs.updateString("Description", des);
            rs.updateString("Consultation_fees", constfee);
            rs.updateLong("MobileNo", mobile);
            rs.updateString("morning_start_time", morningstarttime);
            rs.updateString("morning_end_time", morningendtime);
            rs.updateString("evening_start_time", eveningstarttime);
            rs.updateString("evening_end_time", eveningendtime);
            
            rs.updateString("Services", service);
            rs.updateString("City", city);
            rs.updateString("latitude", lat);
            rs.updateString("longitude", longt);
            rs.updateString("password", password);
          

            if (mon != null)
            {
                rs.updateInt("monday_working", 1);
            }
            if (tues != null)
            {
                rs.updateInt("tuesday_working", 1);
            }
            if (wed != null)
            {
                rs.updateInt("wednesday_working", 1);
            }
            if (thurs != null)
            {
                rs.updateInt("thursday_working", 1);
            }
            if (fri != null)
            {
                rs.updateInt("friday_working", 1);
            }
            if (sat != null)
            {
                rs.updateInt("saturday_working", 1);
            }
            if (sun != null)
            {
                rs.updateInt("sunday_working", 1);
            }
            
            rs.updateString("Profile_Photo","./myuploads"+"/"+myphoto);
            
            rs.insertRow();

            out.println("Doctor added successful");
            response.sendRedirect("DoctorLogin.jsp");

        } 
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    
    
       @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        processRequest(request, response);
    }
    
   @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        doPost(request, response);
    }

   
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }// </editor-fold>

}
