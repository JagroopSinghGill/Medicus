import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class rating_app extends HttpServlet
{
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
         PrintWriter out = response.getWriter();
         
         String rating=request.getParameter("rating");
         String review=request.getParameter("review");
         String username=request.getParameter("username");
        int Doctorid = (Integer.parseInt(request.getParameter("Doctorid")));

         
         try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt1 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
      
            ResultSet rs1 = stmt1.executeQuery("select * from user where username='"+username+"'");
            String email="";
           if(rs1.next())
           {
                email=rs1.getString("Email");
           }
           
           
            Statement stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
      
            ResultSet rs2 = stmt2.executeQuery("select * from rating");
           
                rs2.moveToInsertRow();
                rs2.updateString("RatingValue", rating);
                rs2.updateString("Comments", review);
                rs2.updateString("RatedByUser", email);
                rs2.updateInt("Doctorid", Doctorid);
                rs2.insertRow();
           
        }
         catch(Exception e)
         {
             e.printStackTrace();
         }
         
         
       
    }

}
