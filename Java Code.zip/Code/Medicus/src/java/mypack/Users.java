package mypack;

public class Users
{
   public String username; 
   public String password; 
   
   public Users(String username,String password)
   {
       this.username=username;
       this.password=password;
   }
}
