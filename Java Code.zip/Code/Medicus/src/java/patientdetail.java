import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class patientdetail extends HttpServlet
{
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String PatientName = request.getParameter("PatientName");
        System.out.println(PatientName);
        int PatientAge = Integer.parseInt(request.getParameter("PatientAge"));
        int Doctorid = Integer.parseInt(request.getParameter("Doctorid"));
//        int BookingId = Integer.parseInt(request.getParameter("BookingId"));
        String Problem = request.getParameter("Problem");
        String AppointmentDate = request.getParameter("AppointmentDate");
        String slottime = request.getParameter("slottime");
        System.out.println(slottime);
        String username = request.getParameter("username");
        
        
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "");
            System.out.println("Connection Created");
            Statement stmt1 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
      
            ResultSet rs1 = stmt1.executeQuery("select * from doctors_info2 where doctor_id="+Doctorid);
           int fees=0;
           if(rs1.next())
           {
               fees = rs1.getInt("Consultation_Fees");
           }
            
            Statement stmt2 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
      
            ResultSet rs2 = stmt2.executeQuery("select * from user where username='"+username+"'");
            String email="";
            if(rs2.next())
            {
                email = rs2.getString("email");
            }
            System.out.println(email);
            
            
            
            
            
            
            
            
            
            
            
            
            
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
      
            ResultSet rs = stmt.executeQuery("select * from booking_table");
            System.out.println("ResultSet Created\n\n");
        
             if (rs.next())
            {
                rs.moveToInsertRow();
                rs.updateString("PatientName", PatientName);
                rs.updateString("Problem", Problem);
                rs.updateString("AppointmentDate", AppointmentDate);
                rs.updateString("Email",email);
                rs.updateString("Fees",fees+"");
                rs.updateString("SlotTime",slottime);
                rs.updateInt("PatientAge", PatientAge);
                rs.updateInt("Doctorid", Doctorid);
                rs.insertRow();

            }
            
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

  
}
