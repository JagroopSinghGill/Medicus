
import java.io.*;
import static java.lang.System.out;
import java.sql.*;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import javax.servlet.http.Part;

@MultipartConfig
public class multifilegallery extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
         
            //Part part1= request.getPart("fn");
            Collection<Part> parts = request.getParts();
            String ans = "";
            String myphoto = "";

            String absolutepath = request.getServletContext().getRealPath("/clinic_pics");

            for (Part part : parts) {

                String filename = vmm2.FileUploader.savefileonserver(part, absolutepath);
                //String filename=vmm2.FileUploader.savefileonserver(part,absolutepath,newfilename);
                //you can pass third paramater to change filename on serverside

                if (filename.equals("not-a-file")) {
                    ans += "<br>" + "---";
                } else {
                    ans += "<br>" + filename;
                    myphoto = filename;
                }
            }

            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading Done");

            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");

            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");

            ResultSet rs = stmt.executeQuery("Select * from gallery");
            System.out.println("Result Set Created");
            
            
             String caption = request.getParameter("caption");
             String did = request.getParameter("did");

           rs.moveToInsertRow();
           rs.updateString("caption", caption);
           rs.updateString("did", did);
           rs.updateString("photo_path","./clinic_pics"+ "/" + myphoto);
           rs.insertRow();
             
             out.println("<div class=\"row\">");
             
              Statement stmt1 = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
          
             ResultSet rs1 = stmt1.executeQuery(("select * from gallery where did=" +did));
             
             while(rs.next())
                     {
                      String photo=rs.getString("photo_path");
                       caption=rs.getString("caption");
                      out.println("<div class=\"col-sm-3\">");
                      out.println("<img src =\""+photo+"\" style= \"width:100px ; height:200px\">");
                      out.println("<label>"+caption+"</label>");
                      out.println("</div>");
                      
                      
                      
                     }
             
             out.println("</div>");
             
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
    }

}
