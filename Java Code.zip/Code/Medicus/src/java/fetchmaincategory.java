
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class fetchmaincategory extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       
            PrintWriter out = response.getWriter();
           
            
            System.out.println("in servlet");
             try 
             {
                 Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,  ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs = stmt.executeQuery("select * from doctors_info");
            System.out.println("ResultSet Created\n\n");

                 JSONObject json=new JSONObject();
                 JSONArray jsonarray=new JSONArray();
                 
                 while(rs.next())
                 {
                     String cat_name=  rs.getString("cat_name");
                     String Icon=  rs.getString("Icon");
                     String Description=  rs.getString("Description");
                     
                     JSONObject js= new JSONObject();
                     js.put("Icon",Icon);
                     js.put("Description",Description);
                     js.put("cat_name",cat_name);
                     
                     jsonarray.add(js);
                 
                 }
                 json.put("allcategories",jsonarray);
                 out.println(json);
                         
            
        }
             catch(Exception e)
             {
                 e.printStackTrace();
             }
    }

    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
