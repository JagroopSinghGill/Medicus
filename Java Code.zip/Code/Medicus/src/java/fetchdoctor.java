

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class fetchdoctor extends HttpServlet {

   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            String Sub_Category_Name=request.getParameter("Sub_Category");
            String city = request.getParameter("city");
           System.out.println(Sub_Category_Name);
         try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,  ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs = stmt.executeQuery("select * from doctors_info2 where Sub_Category='"+Sub_Category_Name+"'");
            System.out.println("ResultSet Created\n\n");
            
            JSONObject json= new JSONObject();
            JSONArray jsonarray=new JSONArray();
            
            
            
              while(rs.next())
                 {
                     
                     String Doctor_name = rs.getString("Doctor_name");
                     String Qualification= rs.getString("Qualification");
                     String profile_photo= rs.getString("profile_photo");
                     String Address= rs.getString("Address");
                     String experience= rs.getString("experience");
                     int Doctorid = rs.getInt("doctor_id");
                     System.out.println(Doctor_name);
                   
                     
                     JSONObject js= new JSONObject();
                     js.put("Doctor_name",Doctor_name);
                     js.put("Qualification",Qualification);
                     js.put("profile_photo",profile_photo);
                     js.put("Address",Address);
                     js.put("experience", experience);
                     js.put("doctor_id", Doctorid);
              
                     
                     jsonarray.add(js);
                 
                 }
                 json.put("doctors", jsonarray);
                 out.println(json);
        }
        
        catch(Exception e)
        {
            e.printStackTrace(out);
        }
    }
        
     protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        doGet(request, response);
    }

    
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }// </editor-fold>

        }
    
