import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import vmm.SMSSender;

public class Userservlet1 extends HttpServlet
{

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        
        
             String username= request.getParameter("username");
             String password=  request.getParameter("password");
             String confirmpassword=  request.getParameter("confirmpassword");
       
             String mobile=  request.getParameter("mobile");
             String email= request.getParameter("email");
          try
        {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Driver Loading done");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "Wahegurusb@13");
            System.out.println("Connection Created");
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            System.out.println("Statement Created");
            ResultSet rs = stmt.executeQuery("select * from user where email='"+email+"'");
            System.out.println("ResultSet Created\n\n");
              if (rs.next()) 
              {
                out.println("email already exists");

            } else 
              {
                
            
            rs.moveToInsertRow();
            rs.updateString("username", username);
            rs.updateString("password", password); 
            rs.updateString("confirmpassword", confirmpassword);
            rs.updateString("mobile", mobile);
            rs.updateString("email", email);
            rs.insertRow();
            out.println("Signup Successfull");
            
              }
              
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
    }
    
       public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
    
}


